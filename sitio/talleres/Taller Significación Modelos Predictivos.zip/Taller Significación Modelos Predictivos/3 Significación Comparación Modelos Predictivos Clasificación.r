################################################################################
################################################################################
## TALLER: Significaci�n de Modelos Predictivos 
##         X Jornadas Usuarios de R. Murcia (Nov-2018)
##
## Script: Comparaci�n de 2 Modelos Predictivos
##
## Autor: Jes�s Herranz. GEICAM
################################################################################
################################################################################

rm(list=ls(all=TRUE))

################################################################################
## Librer�as y Funciones
################################################################################

library(e1071)
library(pROC) 
library(caret)

## Se cargan las funciones generales
source ( "C://Taller Significaci�n Modelos Predictivos/Funciones Generales.r")
source ( "C://Taller Significaci�n Modelos Predictivos/Funciones SVM.r")  

################################################################################
## Fichero Datos: Alzheimer
################################################################################

xx = read.csv("C://Taller Significaci�n Modelos Predictivos/Alzheimer.csv", sep=";")
dim(xx)
#head(xx)

xx$Class = as.factor(xx$Class)

n.all = nrow(xx)                 ## N�mero de observaciones 


## Distribuci�n de la Variable Respuesta                       
table ( xx$Class )
prop.table ( table ( xx$Class ) )

## N�mero de la columna donde est� la variable respuesta
column.Resp = which ( names(xx) == "Class" ) 

## N�mero de las columnas de los Predictores de cada uno de los modelos predictivos
names(xx)
column.Mod.BASE = 125:132          ## Modelo Base
column.Mod.ADD = 1:124            ## Variables a a�adir
column.Mod.COM = c ( column.Mod.BASE , column.Mod.ADD )  ## Modelo Completo 

## Normalizaci�n de las Variables (con SVM es necesario)
w.trans = preProcess (  xx [ , - column.Resp ] , method = c ("center", "scale") )
xx [ , - column.Resp ]  = predict( w.trans , xx [ , - column.Resp ] )


################################################################################
## 1.- Construcci�n de los 2 Modelos Predictivos
################################################################################

## Modelo "Final"
mod.base = ProcessSVM ( xx [ , c(column.Mod.BASE, column.Resp)] , 
                        xx [ , c(column.Mod.BASE, column.Resp)] , "Class" )
mod.completo = ProcessSVM ( xx [ , c(column.Mod.COM, column.Resp)] , 
                            xx [ , c(column.Mod.COM, column.Resp)] , "Class" )

## Estimaci�n sobreajustada de la Tasa de Error y el AUC. NO REPORTAR NUNCA !!!!
ErrRate( xx$Class , mod.base$pred.class )$err.rate 
ROCAnalysis ( xx$Class, mod.base$pred.prob [ , "Impaired" ])$AUC
ErrRate( xx$Class , mod.completo$pred.class )$err.rate 
ROCAnalysis ( xx$Class, mod.completo$pred.prob [ , "Impaired" ])$AUC

################################################################################
## 2.- Evaluaci�n de la Capacidad Predictiva con CV de los 2 modelos
################################################################################

## N�mero de folder en la CV (X-fold CV)
n.cv = 10     

## Vectores para almacenar las Tasas de Error y los AUCs
w.err.BASE  = rep ( NA, n.cv )
w.auc.BASE  = rep ( NA, n.cv )
w.err.COM  = rep ( NA, n.cv )
w.auc.COM  = rep ( NA, n.cv )

## Crea el vector "folds" que contiene el grupo (fold) de cada observaci�n  
folds = sample ( rep ( 1:n.cv, length=n.all ) )
  
## Validaci�n Cruzada
for ( ind.cv in 1:n.cv )
{
  ## Creamos los datasets de training y testing en este fold
  cv.train = xx [ folds != ind.cv , ]
  cv.test  = xx [ folds == ind.cv , ] 

  ########################################
  ## Proceso - Modelo Base
  ww.mod.BASE  = ProcessSVM ( cv.train[ , c(column.Mod.BASE, column.Resp)], 
                              cv.test [ , c(column.Mod.BASE, column.Resp)], "Class" )  

  ## Error Rate and AUC - Modelo Base
  w.err.BASE [ind.cv] = ErrRate ( cv.test$Class, ww.mod.BASE$pred.class )$err.rate 
  w.auc.BASE [ind.cv] = ROCAnalysis ( cv.test$Class, ww.mod.BASE$pred.prob[ , "Impaired" ])$AUC
  
  ########################################
  ## Proceso - Modelo Completo  
  ww.mod.COM = ProcessSVM ( cv.train[ , c(column.Mod.COM, column.Resp)], 
                            cv.test [ , c(column.Mod.COM, column.Resp)], "Class" )    
  ## Error Rate and AUC - Modelo Completo
  w.err.COM [ind.cv] = ErrRate ( cv.test$Class, ww.mod.COM$pred.class )$err.rate 
  w.auc.COM [ind.cv] = ROCAnalysis ( cv.test$Class, ww.mod.COM$pred.prob[ , "Impaired" ])$AUC  
}

## Error y AUC medios
ER.Obs.BASE = mean(w.err.BASE)
AUC.Obs.BASE = mean(w.auc.BASE)
AUC.Obs.BASE 
ER.Obs.BASE
ER.Obs.COM = mean(w.err.COM)
AUC.Obs.COM = mean(w.auc.COM)
AUC.Obs.COM 
ER.Obs.COM

################################################################################
## 3.- Significaci�n Estad�stica con Test de Permutaciones con CV
################################################################################

#####################################################
## Permutaciones 
## (100 perms / 20 minutos) ( 10000 perms / 37 horas )
#####################################################

num.perm = 100    ## N�mero de Permutaciones
n.cv = 10         ## N�mero de folder en la CV (X-fold CV)

## Vectores para almacenar la capacidad de cada modelo con Respuesta permutada
perm.AUC = rep ( NA, num.perm )
perm.ER  = rep ( NA, num.perm )

## Proceso de Permutaciones
date()
for ( ind.perm in 1:num.perm )
{    
  ## Permutamos las filas 
  permut = sample ( 1:n.all )                ## Permutamos las Posiciones

  ## Dataframe de trabajo. Se mantienen los predictores del modelo Base y la Respuesta
  ## Se permutar� los predictores a�adidos
  ww = cbind ( xx [        , c ( column.Mod.BASE , column.Resp ) ] , 
               xx [ permut , c ( column.Mod.ADD ) ] )
  names(ww)[ which ( names(ww) == "Class" ) ] = "perm.Class"    ## Cambio de nombre para clarificar


  ######################################################
  ## Proceso de CV con los predictores a�adidos permutados

  ## Matriz para almacenar los errores y los AUCs
  w.error = rep ( NA, n.cv )
  w.auc   = rep ( NA, n.cv )

  ## Crea el vector "folds" que contiene el grupo (fold) de cada observaci�n  
  folds = sample ( rep ( 1:n.cv, length=n.all ) )
    
  ## Validaci�n Cruzada
  for ( ind.cv in 1:n.cv )
  {
      ## Creamos los datasets de training y testing en este fold
      cv.train = ww [ folds != ind.cv , ]
      cv.test  = ww [ folds == ind.cv , ] 

      ## Proceso con la Respuesta Permutada !!!!
      ww.mod = ProcessSVM ( cv.train, cv.test, "perm.Class" )

      ## Error Rate and AUC
      w.error [ind.cv] = ErrRate ( cv.test$perm.Class, ww.mod$pred.class )$err.rate 
      w.auc [ind.cv] = ROCAnalysis ( cv.test$perm.Class, ww.mod$pred.prob[ , "Impaired" ])$AUC
  
  } ## ind.cv

  ## Tasa de Error y AUC para la permutaci�n es la media de AUC y ER de la CV 
  perm.ER[ ind.perm ]  = mean(w.error)
  perm.AUC[ ind.perm ] = mean(w.auc)

} ## ind.perm
date()

                  
######################################################
## C�lculo del P-value del Test de Permutaciones 
perm.p.val.ER  = ( sum ( perm.ER  <= ER.Obs.COM  , na.rm=T ) + 1 ) / (num.perm+1)
perm.p.val.AUC = ( sum ( perm.AUC >= AUC.Obs.COM , na.rm=T ) + 1 ) / (num.perm+1)
perm.p.val.ER
perm.p.val.AUC

## ER y AUC observados
AUC.Obs.BASE 
ER.Obs.BASE
AUC.Obs.COM 
ER.Obs.COM


## Exploramos loas Tasas de Error y AUCs con las respuestas permutadss
sort(perm.ER)[1:8]
mean(perm.ER)
sort(perm.AUC, decreasing=T)[1:8]
mean(perm.AUC)

dev.new()
hist( perm.AUC, main="AUC - permuted response" , xlab="AUC", breaks=30 )
dev.new()
hist( perm.ER, main="ER - permuted response" , xlab="Error Rate", breaks=30 )


