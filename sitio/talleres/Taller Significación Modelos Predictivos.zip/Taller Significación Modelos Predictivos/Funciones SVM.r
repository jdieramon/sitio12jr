################################################################################
################################################################################
## TALLER: Significaci�n de Modelos Predictivos 
##         X Jornadas Usuarios de R. Murcia (Nov-2018)
##
## Script: Funciones del modelo de SUPPORT VECTOR MACHINES (SVM)
##
## Autor: Jes�s Herranz. GEICAM  
################################################################################
################################################################################


################################################################################
################################################################################
## Construcci�n del Modelo con SUPPORT VECTOR MACHINES
## - set.train y set.test son los datasets de training y testing
## - name.resp es el nombre de la variable respuesta (entre comillas)
## - sign.level.sel es el nivel de significaci�n para el filtro basado en 
##   regresi�n log�stica
################################################################################
################################################################################

ProcessSVM = function ( set.train, set.test, name.resp , sign.level.sel = 0.10 )
{

  ## N�mero de la columna donde est� la variable respuesta y los predictores
  w.column.Resp = which ( names(set.train) == name.resp  )
  w.column.Pred = 1:ncol(set.train)
  w.column.Pred = w.column.Pred [ - w.column.Resp ]  ## se quita la col de la resp

  ######################################################
  ## 1.- Seleccci�n de Variables. Filtro Univariante
  
  ## Reporta los p-values de los an�lisis univariantes de regresi�n log�stica de 
  ## cada predictor con la Respuesta binaria
  p.values = FilterUni.Classif ( set.pred = set.train[ , w.column.Pred ] , 
                                 var.resp = set.train [ , name.resp ] )$p.val
  
  ## Columnas de los predictores que cumplen p-value < sign.level.sel
  ## Si no hay ninguna se selecciona la del p-value m�nimo 
  if ( min(p.values ) < sign.level.sel ) 
  { column.sel = w.column.Pred [ which ( p.values < sign.level.sel ) ] }
  else { column.sel = w.column.Pred [ which.min ( p.values ) ] }
  
  ## Data frame con la Respuesta y los predictores con p-value < sign.level.sel 
  set.train.sel = set.train [  , c ( column.sel , w.column.Resp ) ]
  
  
  ######################################################
  ## 2.- Optimizaci�n de par�metros de SVM

  tune.rad <- tune.svm( as.formula ( paste ( name.resp , " ~ . " ) ) , 
                        data = set.train.sel, kernel="radial", 
                        gamma = c( 0.01, 0.005, 0.001 ) , 
                        cost = c( 5, 10, 50 ) , 
                        tunecontrol = tune.control ( cross = 5 ) )

                
  ######################################################
  ## 3.- SVM con los par�metros �ptimos del paso anterior

  svm.out = svm( as.formula ( paste ( name.resp , " ~ . " ) ) , 
                 data = set.train.sel, kernel="radial", 
                 gamma=tune.rad$best.parameters$gamma, 
                 cost=tune.rad$best.parameters$cost, 
                 probability=TRUE )

  ######################################################
  ## 4.- Predicci�n en el conjunto de testing

  ## Clases
  svm.class =  predict( svm.out, newdata = set.test )

  ## Probabilidades
  svm.pred = predict( svm.out, newdata = set.test, decision.values=TRUE, probability=TRUE)
  svm.prob = attr(svm.pred, "probabilities" ) 

  ######################################################
  ## OUTPUT: Modelo construido y Predicci�n en el conjunto de testing
  list( out.mod = svm.out , 
        pred.prob = svm.prob, pred.class = svm.class  ) 
}
