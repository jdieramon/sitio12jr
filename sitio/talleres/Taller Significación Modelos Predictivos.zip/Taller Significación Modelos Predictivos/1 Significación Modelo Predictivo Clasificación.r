################################################################################
################################################################################
## TALLER: Significaci�n de Modelos Predictivos 
##         X Jornadas Usuarios de R. Murcia (Nov-2018)
##
## Script: Significaci�n de un Modelo Predictivo
##
## Autor: Jes�s Herranz. GEICAM
################################################################################
################################################################################

rm(list=ls(all=TRUE))

################################################################################
## Librer�as y Funciones
################################################################################

library(e1071)     
library(pROC)       
library(caret)

## Se cargan las funciones generales
source ( "C://Taller Significaci�n Modelos Predictivos/Funciones Generales.r") 
source ( "C://Taller Significaci�n Modelos Predictivos/Funciones SVM.r") 

################################################################################
## Fichero Datos: Alzheimer
################################################################################

xx = read.csv("C://Taller Significaci�n Modelos Predictivos/Alzheimer.csv", sep=";")
dim(xx)
#head(xx)

xx$Class = as.factor(xx$Class)

n.all = nrow(xx)                 ## N�mero de observaciones 


## Distribuci�n de la Variable Respuesta                       
table ( xx$Class )
prop.table ( table ( xx$Class ) )

## N�mero de la columna donde est� la variable respuesta
column.Resp = which ( names(xx) == "Class" ) 

## Normalizaci�n de las Variables (con SVM es necesario)
w.trans = preProcess (  xx [ , - column.Resp ] , method = c ("center", "scale") )
xx [ , - column.Resp ]  = predict( w.trans , xx [ , - column.Resp ] )


################################################################################
## 1.- Construcci�n del Modelo Predictivo
################################################################################

## Modelo "Final". Proceso completo (SV + OP + CM)
mod.all = ProcessSVM ( xx, xx, "Class" )
names(mod.all)
class(mod.all$out.mod)

## Estimaci�n sobreajustada de la Tasa de Error y el AUC. NO REPORTAR NUNCA !!!!
ErrRate( xx$Class , mod.all$pred.class )$err.rate 
ROCAnalysis ( xx$Class, mod.all$pred.prob [ , "Impaired" ])$AUC


################################################################################
## 2.- Evaluaci�n de la Capacidad Predictiva con CV 
################################################################################

## N�mero de folder en la CV (X-fold CV)
n.cv = 10     

## Vectores para almacenar las Tasas de Error y los AUCs
w.error = rep ( NA, n.cv )
w.auc   = rep ( NA, n.cv )

## Crea el vector "folds" que contiene el grupo (fold) de cada observaci�n  
folds = sample ( rep ( 1:n.cv, length=n.all ) )
head(folds)
table (folds)

  
## Validaci�n Cruzada
for ( ind.cv in 1:n.cv )
{
  ## Creamos los datasets de training y testing en este fold
  cv.train = xx [ folds != ind.cv , ]
  cv.test  = xx [ folds == ind.cv , ] 

  ## Proceso completo (SV + OP + CM)
  ww.mod = ProcessSVM ( cv.train, cv.test, "Class" )  

  ## Error Rate and AUC
  w.error [ind.cv] = ErrRate ( cv.test$Class, ww.mod$pred.class )$err.rate 
  w.auc [ind.cv] = ROCAnalysis ( cv.test$Class, ww.mod$pred.prob[ , "Impaired" ])$AUC
}

## Error y AUC medios
ER.Obs = mean(w.error)
AUC.Obs = mean(w.auc)
AUC.Obs 
ER.Obs


################################################################################
## 3.- Significaci�n Estad�stica con Test de Permutaciones con CV
################################################################################

#####################################################
## Permutaciones 
## (100 perms / 20 minutos) ( 10000 perms / 37 horas )
#####################################################

num.perm = 100    ## = 10000  ## N�mero de Permutaciones
n.cv = 10         ## N�mero de folder en la CV (X-fold CV)

## Vectores para almacenar la capacidad de cada modelo con Respuesta permutada
perm.AUC = rep ( NA, num.perm )
perm.ER  = rep ( NA, num.perm )

## Proceso de Permutaciones
date()
for ( ind.perm in 1:num.perm )      
{ 
  ## Dataframe de trabajo (se mantienen los predictores y se permutar� la respuesta)
  ww = xx
  
  ## Permutamos los valores de la Variable Respuesta
  permut = sample ( 1:n.all )                ## Permutamos las Posiciones
  ww$Class = xx$Class [ permut ]             ## Permutamos los Valores de Y
  names(ww)[ column.Resp ] = "perm.Class"    ## Cambio de nombre para clarificar

  ######################################################
  ## Proceso de CV con la respuesta permutada

  ## Vectores para almacenar los errores y los AUCs
  w.error = rep ( NA, n.cv )
  w.auc   = rep ( NA, n.cv )

  ## Crea el vector "folds" que contiene el grupo (fold) de cada observaci�n  
  folds = sample ( rep ( 1:n.cv, length=n.all ) )
  
  ## Validaci�n Cruzada
  for ( ind.cv in 1:n.cv )
  {
      ## Creamos los datasets de training y testing en este fold
      cv.train = ww [ folds != ind.cv , ]
      cv.test  = ww [ folds == ind.cv , ] 

      ## Proceso con la Respuesta Permutada !!!!
      ww.mod = ProcessSVM ( cv.train, cv.test, "perm.Class" )

      ## Error Rate and AUC
      w.error [ind.cv] = ErrRate ( cv.test$perm.Class, ww.mod$pred.class )$err.rate 
      w.auc [ind.cv] = ROCAnalysis ( cv.test$perm.Class, ww.mod$pred.prob[ , "Impaired" ])$AUC
  
  } ## ind.cv

  ## Tasa de Error y AUC para la permutaci�n es la media de AUC y ER de la CV 
  perm.ER[ ind.perm ]  = mean(w.error)
  perm.AUC[ ind.perm ] = mean(w.auc)

} ## ind.perm
date()

######################################################
## C�lculo del P-value del Test de Permutaciones 
perm.p.val.ER  = ( sum ( perm.ER  <= ER.Obs  , na.rm=T ) + 1 ) / (num.perm+1)
perm.p.val.AUC = ( sum ( perm.AUC >= AUC.Obs , na.rm=T ) + 1 ) / (num.perm+1)
perm.p.val.ER
perm.p.val.AUC

## ER y AUC observados                         
ER.Obs
AUC.Obs 

## Exploramos las Tasas de Error y AUCs con las respuestas permutadas
sort(perm.ER)[1:8]
mean(perm.ER)
sort(perm.AUC, decreasing=T)[1:8]
mean(perm.AUC)

dev.new()
hist( perm.AUC, main="AUC - permuted response" , xlab="AUC", breaks=30 )
dev.new()
hist( perm.ER, main="ER - permuted response" , xlab="Error Rate", breaks=30 )


