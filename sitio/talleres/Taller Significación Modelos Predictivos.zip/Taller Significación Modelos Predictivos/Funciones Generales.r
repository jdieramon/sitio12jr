################################################################################
################################################################################
## TALLER: Significaci�n de Modelos Predictivos 
##         X Jornadas Usuarios de R. Murcia (Nov-2018)
##
## Script: Funciones generales
##
## Autor: Jes�s Herranz. GEICAM  
################################################################################
################################################################################


################################################################################
## An�lisis de Curvas ROC (con el paquete pROC)
################################################################################
     
ROCAnalysis = function ( bin.var, cont.var, last = TRUE, 
                         ci = FALSE, plot = FALSE, ... )
{
  ## Comprobamos la variable binaria
  if ( length( unique (bin.var ) ) != 2 ) 
  { stop ( "La Variable bin.var debe ser binaria" ) }   
  
  ## ROC Analysis
  ## Si se predice la �ltima categor�a (last=TRUE), la direcci�n del predictor 
  ## es "<", los valores altos corresponden a los casos (controls < t <= cases)
  if ( last == TRUE ) { roc.out <- roc( bin.var , cont.var, direction="<" ) }
  else                { roc.out <- roc( bin.var , cont.var, direction=">" ) }

  ## AUC con IC95%
  w.auc  = pROC::auc (roc.out) 
  if ( ci == TRUE ) { w.ci   = ci.auc (roc.out)  } 

  ## Plot de la Curva ROC (opcional)
  if ( plot == TRUE )
  {
    dev.new()
    plot( roc.out , legacy.axes = TRUE, col="red" , ... )
    text (0.2, 0.2, paste("AUC = ", round(w.auc ,3 )))
  }

  ## Output
  if ( ci == TRUE ) { list ( AUC = w.auc[1] , CI.AUC = c( w.ci[1] , w.ci[3] ) ) }
  else              { list ( AUC = w.auc[1] ) }
}

################################################################################
## Error Rate: Tasa de Error
################################################################################

ErrRate = function ( obs, pred )
{ 
  ## Deben tener la misma longitud
  if ( length(obs) != length(pred) ) 
  { stop ( "Los vectores deben tener la misma longitud" ) }   
  
  ## Tabla 
  tt = table( obs, pred )
   
  ## Proporci�n de Buenas y Malas clasificaciones
  accuracy = sum ( as.character(obs) == as.character(pred) ) 
 
  accuracy = accuracy / sum(tt)
  
  err.rate = 1 - accuracy
  
  list( accuracy = accuracy, err.rate = err.rate )
}


################################################################################
## Medidas de Evaluaci�n de Modelos de Regresi�n (Var. Respuesta Cuantitativa)
################################################################################

EvalRegr = function ( obs, pred )
{ 
  ## Deben tener la misma longitud
  if ( length(obs) != length(pred) ) 
  { stop ( "Los vectores deben tener la misma longitud" ) }   
  
  ## MSE y RMSE
  mse = mean ( ( obs - pred ) ** 2 )
  rmse = sqrt ( mse)
  
  ## Error Estandard del MSE
  ## El SE se calcula como el SD(res^2)/sqrt(n) porque el MSE es uma media de res^2 
  se.mse = sd ( ( obs - pred ) ** 2 ) / sqrt(length(obs))  

  ## MAE  
  mae = mean ( abs( obs - pred ) )

  ## R2
  R2 = cor ( obs, pred ) ** 2

  ## Par�metros de salida
  list( MSE = mse, RMSE = rmse, MAE = mae, R2 = R2, SE.MSE = se.mse )
  
}                

################################################################################
## Selecci�n de Variables. Filtro basado en P-valores con Respuesta binaria
################################################################################
     
FilterUni.Classif = function ( set.pred , var.resp )
{ 
  ## Se controla que Y es una variable binaria
  if( length(unique(var.resp)) != 2 ) stop("La variable respuesta debe ser binaria")
  
  ## Para cada variable se extrae el P-valor del LRT de la Regresi�n Log�stica
  p.val = apply( set.pred, 2 , function ( w.col ) 
                           { out.log = glm( var.resp ~ w.col, family=binomial )
                             anova(out.log, test="Chisq" )$"Pr(>Chi)"[2] } ) 
  
  ## Par�metros de salida: P-valores en el mismo orden que los predictores en set.pred
  list ( p.val = p.val )
}

