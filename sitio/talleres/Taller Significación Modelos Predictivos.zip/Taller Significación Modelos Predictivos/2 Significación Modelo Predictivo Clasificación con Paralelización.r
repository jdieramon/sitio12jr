################################################################################
################################################################################
## TALLER: Significaci�n de Modelos Predictivos 
##         X Jornadas Usuarios de R. Murcia (Nov-2018)
##
## Script: Significaci�n de un Modelo Predictivo con paralelizaci�n
##
## Autor: Jes�s Herranz. GEICAM
################################################################################
################################################################################

rm(list=ls(all=TRUE))

################################################################################
## PARAL-1: Paquete que permite la paralelizaci�n
library(parallel)          


################################################################################
## PARAL-2: Inicializa los Cluster
################################################################################

## Se pregunta por el n�mero de cores del ordenador y se inicializan, dejando 
## un procesador libre

nc <- detectCores() - 1 
nc      
w.cluster <- makeCluster( nc )   

## Para declarar un n�mero fijo, 28, se podr�a poner: 
## w.cluster <- makeCluster( 28 )   


################################################################################
################################################################################
## PARAL-3: Con la funci�n "clusterEvalQ" se cargan los paquetes, los datos y 
## las variables en cada Worker, que es el primer par�metro
################################################################################
################################################################################

ignore = clusterEvalQ ( w.cluster, 
{ 

################################################################################
## Librer�as y Funciones
################################################################################

library(e1071)
library(pROC) 
library(caret)

## Se cargan las funciones generales
source ( "C://Taller Significaci�n Modelos Predictivos/Funciones Generales.r")
source ( "C://Taller Significaci�n Modelos Predictivos/Funciones SVM.r")  


################################################################################
## Fichero Datos: Alzheimer
################################################################################

xx = read.csv("C://Taller Significaci�n Modelos Predictivos/Alzheimer.csv", sep=";")
dim(xx)
#head(xx)

xx$Class = as.factor(xx$Class)

## N�mero de la columna donde est� la variable respuesta
column.Resp = which ( names(xx) == "Class" ) 

## Normalizaci�n de las Variables (con SVM es necesario)
w.trans = preProcess (  xx [ , - column.Resp ] , method = c ("center", "scale") )
xx [ , - column.Resp ]  = predict( w.trans , xx [ , - column.Resp ] )


################################################################################
## PARAL-4: Se define dentro de cada Cluster una funci�n que es la que hace UNA 
## PERMUTACI�N, y que ser� llamado con una funci�n de la familia "apply"
## - Contiene b�sicamente el c�digo del "for" del bucle de permutaciones
## - El df "xx" aqu� se introducir� en un par�metro "par.xx"
################################################################################

SVM.Perm.Paralelo = function ( par.ind.perm , par.xx , n.cv=10 )
{

  ## Dataframe de trabajo (se mantienen los predictores y se permutar� la respuesta)
  ww = par.xx
  n.all = nrow(par.xx)          ## Se ha a�adido en la paralelizaci�n
  
  ## Permutamos los valores de la Variable Respuesta
  permut = sample ( 1:n.all )                ## Permutamos las Posiciones
  ww$Class = par.xx$Class [ permut ]         ## Permutamos los Valores de Y
  names(ww)[ column.Resp ] = "perm.Class"    ## Cambio de nombre para clarificar


  ######################################################
  ## Proceso de CV con la respuesta permutada

  ## Vectores para almacenar los errores y los AUCs
  w.error = rep ( NA, n.cv )
  w.auc   = rep ( NA, n.cv )

  ## Crea el vector "folds" que contiene el grupo (fold) de cada observaci�n  
  folds = sample ( rep ( 1:n.cv, length=n.all ) )
  
  ## Validaci�n Cruzada
  for ( ind.cv in 1:n.cv )
  {
      ## Creamos los datasets de training y testing en este fold
      cv.train = ww [ folds != ind.cv , ]
      cv.test  = ww [ folds == ind.cv , ] 

      ## Proceso con la Respuesta Permutada !!!!
      ww.mod = ProcessSVM ( cv.train, cv.test, "perm.Class" )

      ## Error Rate and AUC
      w.error [ind.cv] = ErrRate ( cv.test$perm.Class, ww.mod$pred.class )$err.rate 
      w.auc [ind.cv] = ROCAnalysis ( cv.test$perm.Class, ww.mod$pred.prob[ , "Impaired" ])$AUC
  
  } ## ind.cv

  ## Tasa de Error y AUC para la permutaci�n es la media de AUC y ER de la CV 
  #perm.ER[ ind.perm ]  = mean(w.error)
  #perm.AUC[ ind.perm ] = mean(w.auc)

  #######################
  ## OUTPUT: Los resultados de la permutaci�n son el ER y AUC
  list ( par.ind.perm = par.ind.perm, 
         out.ER = mean(w.error) , 
         out.AUC = mean(w.auc) )
} ## end-function SVM.Perm.Paralelo


## PARAL-5: aqu� se cierra la funci�n ""clusterEvalQ" 
  NULL      ## No devuelve nada

} ) ## final de las �rdenes de R (2� par�metro) y final de la funci�n "clusterEvalQ�


################################################################################
## PARAL-6: EJECUCI�N del Proceso
## - Aqu� se ejecuta la funci�n en los Clusters que est�n inicializados 
################################################################################

 
#####################################################
## PARAL-7: Esta es la funci�n "apply" que ejecuta la funci�n en cada cluster
## repartiendo el "set.perm" entre ellos

## Conjunto de permutaciones que se van a ejecutar, en un vector
set.perm = 1:100

time1 = Sys.time()    ## para controlar el tiempo que tarda

perm.out  = clusterApply ( w.cluster, set.perm,  
              function ( w.ind ) SVM.Perm.Paralelo ( par.ind.perm = w.ind , par.xx = xx , n.cv=10 ) )

time2 = Sys.time()
difftime ( time2 , time1 , units = "mins"  )


#####################################################
## PARAL-8: MUY IMPORTANTE: Se cierran los clusters para liberar los procesadores

stopCluster(w.cluster)


#####################################################
## PARAL-9: Resultados del Proceso

## Explorando el objeto "perm.out" que devuelve: es una lista con una componente
## para cada permutaci�n, que contiene la salida de la funci�n "SVM.Perm.Paralelo"
class( perm.out)
length ( perm.out )
perm.out[[1]]


## Para obtener vectores uniendo todos los resultados
## Estos resultados habr�a que salvarlos y en otro script calcular los ER y AUC
## de los datos observados
perm.ER   = as.numeric( unlist( sapply( perm.out , '[' , 'out.ER'  ))) 
perm.AUC  = as.numeric( unlist( sapply( perm.out , '[' , 'out.AUC' ))) 


## Exploramos las Tasas de Error y AUCs con las respuestas permutadss
length(perm.ER)
sort(perm.ER)[1:8]
mean(perm.ER)
length(perm.AUC)
sort(perm.AUC, decreasing=T)[1:8]
mean(perm.AUC)

dev.new()
hist( perm.AUC, main="AUC - permuted response" , xlab="AUC", breaks=20 )
dev.new()
hist( perm.ER, main="ER - permuted response" , xlab="Error Rate", breaks=20 )


